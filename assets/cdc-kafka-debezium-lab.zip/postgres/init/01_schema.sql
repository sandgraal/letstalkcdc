CREATE TABLE IF NOT EXISTS public.customers (
  id SERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.orders (
  id BIGSERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES public.customers(id),
  status TEXT NOT NULL DEFAULT 'NEW',
  total_cents INT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.orders_materialized (
  id BIGINT PRIMARY KEY,
  customer_id INT NOT NULL,
  status TEXT NOT NULL,
  total_cents INT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);
INSERT INTO public.customers (full_name, email) VALUES
  ('Ada Lovelace','ada@example.com'),
  ('Grace Hopper','grace@example.com'),
  ('Katherine Johnson','kj@example.com')
ON CONFLICT DO NOTHING;
INSERT INTO public.orders (customer_id, status, total_cents) VALUES
  (1, 'NEW', 1299),
  (2, 'NEW', 2599),
  (3, 'NEW', 4599)
ON CONFLICT DO NOTHING;
