#!/usr/bin/env python3
import os, json
from kafka import KafkaConsumer
import psycopg2

KAFKA_BROKERS = os.getenv("KAFKA_BROKERS", "localhost:9094")
TOPIC = os.getenv("TOPIC", "dbz.public.orders")
PG_DSN = os.getenv("PG_DSN", "dbname=inventory user=postgres password=postgres host=localhost port=5432")

def ensure_table(conn):
    with conn, conn.cursor() as cur:
        cur.execute("CREATE TABLE IF NOT EXISTS public.orders_materialized (id BIGINT PRIMARY KEY, customer_id INT, status TEXT, total_cents INT, updated_at TIMESTAMPTZ)")

def upsert(conn, after):
    with conn, conn.cursor() as cur:
        cur.execute(
            """INSERT INTO public.orders_materialized (id,customer_id,status,total_cents,updated_at)
            VALUES (%(id)s,%(customer_id)s,%(status)s,%(total_cents)s,%(updated_at)s)
            ON CONFLICT (id) DO UPDATE SET customer_id=EXCLUDED.customer_id,status=EXCLUDED.status,total_cents=EXCLUDED.total_cents,updated_at=EXCLUDED.updated_at""", after)

def delete(conn, before):
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM public.orders_materialized WHERE id=%s", (before["id"],))

def main():
    consumer = KafkaConsumer(
        TOPIC, bootstrap_servers=KAFKA_BROKERS.split(","),
        auto_offset_reset="earliest", enable_auto_commit=True,
        value_deserializer=lambda m: json.loads(m.decode("utf-8"))
    )
    conn = psycopg2.connect(PG_DSN)
    ensure_table(conn)
    for msg in consumer:
        val = msg.value
        op = val.get("op")
        after = val.get("after")
        before = val.get("before")
        if op in ("c","u") and after:
            upsert(conn, after); conn.commit()
            print("UPSERT", after)
        elif op=="d" and before:
            delete(conn,before); conn.commit()
            print("DELETE", before)
if __name__=="__main__": main()
