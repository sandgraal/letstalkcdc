# Outbox Pattern Add-on (Debezium Event Router)

This add-on layers an **outbox table** and a second Debezium connector that routes business events to topics like `outbox.order`.

## Files
- `postgres/init/02_outbox.sql` — creates `public.outbox` (UUID id, aggregate_type/id, type, payload JSONB, created_at)
- `connect/connector-outbox.json` — Debezium connector using **EventRouter** SMT
- `connect/register-outbox.sh` — helper to register the outbox connector
- `examples/txn.sql` — sample SQL showing a domain change and outbox insert in the same transaction
- `consumer/outbox_consumer.py` — demo consumer that prints business events from `outbox.order`

## Usage (assumes the base lab stack is running)
```bash
# 1) Apply outbox schema (containers already mount /postgres/init on first boot).
#    If the Postgres container is already running, exec and run the SQL:
docker exec -i pg psql -U postgres -d inventory < postgres/init/02_outbox.sql

# 2) Register the outbox connector
cd connect
./register-outbox.sh

# 3) Produce events using a single transaction
docker exec -it pg psql -U postgres -d inventory -f /docker-entrypoint-initdb.d/02_outbox.sql
# or paste commands from examples/txn.sql into a psql session

# 4) Consume business events
cd consumer
python -m venv .venv && source .venv/bin/activate
pip install kafka-python==2.0.2
python outbox_consumer.py  # reads from 'outbox.order' by default
```
