-- Outbox table for Debezium Event Router SMT
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.outbox (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  aggregate_type TEXT NOT NULL,          -- e.g., 'order'
  aggregate_id TEXT NOT NULL,            -- e.g., order id
  type TEXT NOT NULL,                    -- e.g., 'order_created', 'order_paid'
  payload JSONB NOT NULL,                -- business event payload
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Helpful index for relay/queries if needed
CREATE INDEX IF NOT EXISTS idx_outbox_created_at ON public.outbox (created_at);
