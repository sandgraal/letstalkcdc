#!/usr/bin/env python3
import os, json
from kafka import KafkaConsumer

# Consumes business events from the outbox topic(s), e.g. 'outbox.order'
KAFKA_BROKERS = os.getenv("KAFKA_BROKERS", "localhost:9094")
TOPIC = os.getenv("TOPIC", "outbox.order")

def main():
    print(f"Consuming {TOPIC} from {KAFKA_BROKERS}")
    consumer = KafkaConsumer(
        TOPIC,
        bootstrap_servers=KAFKA_BROKERS.split(","),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="outbox-demo",
        value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        key_deserializer=lambda m: json.loads(m.decode("utf-8")) if m else None,
    )
    for msg in consumer:
        key = msg.key
        val = msg.value
        headers = {k:v.decode('utf-8') if isinstance(v, (bytes,bytearray)) else v for (k,v) in msg.headers}
        print(f"[{msg.topic}] key={key} type={headers.get('type')} payload={val}")

if __name__ == "__main__":
    main()
