-- Simulated application transaction using the outbox pattern
BEGIN;

-- 1) Domain change
INSERT INTO public.orders (customer_id, status, total_cents)
VALUES (1, 'NEW', 1999)
RETURNING id INTO TEMP TABLE _o(id);

-- 2) Business event in the outbox (same transaction)
INSERT INTO public.outbox (aggregate_type, aggregate_id, type, payload)
SELECT
  'order' AS aggregate_type,
  id::text AS aggregate_id,
  'order_created' AS type,
  jsonb_build_object(
    'order_id', id,
    'customer_id', 1,
    'status', 'NEW',
    'total_cents', 1999,
    'ts', now()
  )
FROM _o;

COMMIT;

-- Another example: update -> order_paid
WITH updated AS (
  UPDATE public.orders SET status='PAID', total_cents=2099, updated_at=now()
  WHERE id = (SELECT id FROM _o LIMIT 1)
  RETURNING id, customer_id, status, total_cents
)
INSERT INTO public.outbox (aggregate_type, aggregate_id, type, payload)
SELECT
  'order', id::text, 'order_paid',
  jsonb_build_object(
    'order_id', id,
    'customer_id', customer_id,
    'status', status,
    'total_cents', total_cents,
    'ts', now()
  )
FROM updated;
