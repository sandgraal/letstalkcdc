#!/usr/bin/env bash
set -euo pipefail
curl -sS -X POST -H "Content-Type: application/json"   --data @connector-outbox.json http://localhost:8083/connectors | jq . || true
echo "Outbox connector POSTed."
